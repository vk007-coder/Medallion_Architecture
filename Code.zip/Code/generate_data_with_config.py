﻿import csv
import random
import datetime
import os
import json

# Default config path (update this if needed)
DEFAULT_CONFIG_FILE = r"C:/Users/konde/Desktop/Project/Config/config.json"


def load_config(config_file=DEFAULT_CONFIG_FILE):
    """
    Loads configuration from a JSON file. If it doesn't exist or is invalid,
    returns a default config dictionary.
    """
    default_config = {
        "paths": {
            "output_folder": "C:/Users/konde/Desktop/Project/Data",  # Updated path
            "tracker_file": "C:/Users/konde/Desktop/Project/id_tracker.json"
        },
        "data_settings": {
            "num_rows_per_table": 500
        }
    }

    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as f:
                user_config = json.load(f)
            print(f"✅ Config loaded from: {config_file}")
            # Merge user_config into default_config (shallow merge)
            for key, value in user_config.items():
                if key in default_config and isinstance(value, dict):
                    default_config[key].update(value)
                else:
                    default_config[key] = value
        except (json.JSONDecodeError, IOError):
            print(f"⚠️ Warning: Could not read/parse '{config_file}'. Using default config.")
    else:
        print(f"⚠️ Warning: Config file '{config_file}' not found. Using default config.")

    return default_config


def load_id_tracker(tracker_path):
    """Load the last used IDs from a JSON file (tracker_path)."""
    if os.path.exists(tracker_path):
        try:
            with open(tracker_path, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            pass  # Fall back to default
    return {"customers": 10000, "products": 10000, "orders": 10000, "order_items": 10000}


def save_id_tracker(tracker, tracker_path):
    """Save the updated ID tracker to a JSON file."""
    with open(tracker_path, 'w') as f:
        json.dump(tracker, f, indent=2)


def random_date(start_date, end_date):
    """Generate a random date between start_date and end_date."""
    start_ts = int(start_date.timestamp())
    end_ts = int(end_date.timestamp())
    rand_ts = random.randint(start_ts, end_ts)
    return datetime.date.fromtimestamp(rand_ts)


def generate_customers(num_rows, start_id):
    """Generate 'customers' table data."""
    states = ["NY", "CA", "TX", "IL", "FL", "WA", "MA", "OH", "GA", "NC"]
    cities = ["New York", "Los Angeles", "Houston", "Chicago", "Miami",
              "Seattle", "Boston", "Cleveland", "Atlanta", "Charlotte"]

    return [
        [i, f"Customer {i}", f"customer{i}@example.com",
         f"{random.randint(1, 9999)} {random.choice(['Main St', 'Oak Ave', 'Pine Rd'])}",
         random.choice(cities), random.choice(states)]
        for i in range(start_id, start_id + num_rows)
    ]


def generate_products(num_rows, start_id):
    """Generate 'products' table data."""
    categories = ["Electronics", "Wearables", "Home Decor", "Kitchen", "Sports"]

    return [
        [i, f"Product {i}", random.choice(categories), round(random.uniform(5.0, 1000.0), 2)]
        for i in range(start_id, start_id + num_rows)
    ]


def generate_orders(num_rows, start_id, max_customer_id, order_date=None):
    """Generate 'orders' table data."""
    order_statuses = ["SHIPPED", "PENDING", "CANCELLED", "DELIVERED"]
    start_range = datetime.date(2024, 1, 1)
    end_range = datetime.date(2025, 1, 1)

    return [
        [i, order_date if order_date else random_date(start_range, end_range),
         random.randint(1, max_customer_id), round(random.uniform(0.0, 5000.0), 2),
         random.choice(order_statuses)]
        for i in range(start_id, start_id + num_rows)
    ]


def generate_order_items(num_rows, start_id, max_order_id, max_product_id):
    """Generate 'order_items' table data."""
    return [
        [i, random.randint(1, max_order_id), random.randint(1, max_product_id),
         random.randint(1, 10), round(random.uniform(5.0, 500.0), 2)]
        for i in range(start_id, start_id + num_rows)
    ]


def write_csv(file_name, header, rows):
    """Write data to a CSV file."""
    os.makedirs(os.path.dirname(file_name), exist_ok=True)
    with open(file_name, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)


def main():
    """Main function to generate data and write to CSVs."""
    config = load_config()
    output_folder = config["paths"]["output_folder"]
    tracker_file = config["paths"]["tracker_file"]
    num_rows = config["data_settings"]["num_rows_per_table"]

    os.makedirs(output_folder, exist_ok=True)

    tracker = load_id_tracker(tracker_file)

    run_date = datetime.date.today()
    file_timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

    # Generate data
    customers_data = generate_customers(num_rows, tracker["customers"] + 1)
    tracker["customers"] += num_rows

    products_data = generate_products(num_rows, tracker["products"] + 1)
    tracker["products"] += num_rows

    orders_data = generate_orders(num_rows, tracker["orders"] + 1, tracker["customers"], run_date)
    tracker["orders"] += num_rows

    order_items_data = generate_order_items(num_rows, tracker["order_items"] + 1, tracker["orders"],
                                            tracker["products"])
    tracker["order_items"] += num_rows

    save_id_tracker(tracker, tracker_file)

    # Define folders for each data type
    customers_folder = os.path.join(output_folder, "customers")
    products_folder = os.path.join(output_folder, "products")
    orders_folder = os.path.join(output_folder, "orders")
    order_items_folder = os.path.join(output_folder, "order_items")

    # Create respective folders if they don't exist
    os.makedirs(customers_folder, exist_ok=True)
    os.makedirs(products_folder, exist_ok=True)
    os.makedirs(orders_folder, exist_ok=True)
    os.makedirs(order_items_folder, exist_ok=True)

    # Write CSVs in respective folders
    customers_file = os.path.join(customers_folder, f"raw_customers_{file_timestamp}.csv")
    products_file = os.path.join(products_folder, f"raw_products_{file_timestamp}.csv")
    orders_file = os.path.join(orders_folder, f"raw_orders_{file_timestamp}.csv")
    order_items_file = os.path.join(order_items_folder, f"raw_order_items_{file_timestamp}.csv")

    write_csv(customers_file, ["customer_id", "full_name", "email", "address", "city", "state"], customers_data)
    write_csv(products_file, ["product_id", "product_name", "category", "price"], products_data)
    write_csv(orders_file, ["order_id", "order_date", "customer_id", "total_amount", "order_status"], orders_data)
    write_csv(order_items_file, ["order_item_id", "order_id", "product_id", "quantity", "unit_price"], order_items_data)

    print(f"\n✅ Files generated for data date: {run_date}")
    print(f"  {customers_file}")
    print(f"  {products_file}")
    print(f"  {orders_file}")
    print(f"  {order_items_file}")
    print("\n🔹 Updated ID tracker stored in:", tracker_file)
    print(json.dumps(tracker, indent=2))


if __name__ == "__main__":
    main()
