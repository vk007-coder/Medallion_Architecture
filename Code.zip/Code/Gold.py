from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

order_items_order_id_in_order = spark.read.csv(r"C:\Users\konde\Desktop\Data\Scripts\Silver\order_items_order_id_in_order",header=True)
orders_customer_id_in_customer = spark.read.csv(r"C:\Users\konde\Desktop\Data\Scripts\Silver\orders_customer_id_in_customer",header=True)
order_items_product_id_in_product_id = spark.read.csv(r"C:\Users\konde\Desktop\Data\Scripts\Silver\order_items_product_id_in_product_id",header=True)

orders_customer_id_in_customer = orders_customer_id_in_customer.select('customer_id','city','state')

order_items_order_id_in_order = order_items_order_id_in_order.withColumnRenamed('customer_id','os_customer_id')
final_df = order_items_order_id_in_order.join(orders_customer_id_in_customer,order_items_order_id_in_order.os_customer_id==orders_customer_id_in_customer.customer_id,'left')
final_df = final_df.filter(
    (final_df.os_customer_id.isNotNull()) &
    (final_df.order_status != "CANCELLED")
)

final_df = final_df.drop('customer_id').withColumnRenamed('os_customer_id','customer_id')
final_df = final_df.select('customer_id','product_id','order_id','order_item_id','quantity','unit_price','Ingest_timestamp','Source_system','order_date','total_amount','order_status','os_ingest_timestamp','os_source_system','city','state')
final_df.show()
final_df.write.mode('overwrite').option('headet','true').csv(r"C:\Users\konde\Desktop\Data\Scripts\Gold")


