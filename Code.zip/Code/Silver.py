from pyspark.sql import SparkSession
from pyspark.sql.functions import *

spark = SparkSession.builder.getOrCreate()

customer_silver_df = spark.read.csv(r"C:\Users\konde\Desktop\Data\Scripts\bronze\customers\2025-02-03",header=True)
orders_item_silver_df = spark.read.csv(r"C:\Users\konde\Desktop\Data\Scripts\bronze\Order_items\2025-02-03",header=True)
orders_silver_df = spark.read.csv(r"C:\Users\konde\Desktop\Data\Scripts\bronze\orders\2025-02-03",header=True)
Products_silver_df = spark.read.csv(r"C:\Users\konde\Desktop\Data\Scripts\bronze\Products\2025-02-03",header=True)

customer_silver_df.limit(5).show()
orders_item_silver_df.limit(5).show()
orders_silver_df.limit(5).show()
Products_silver_df.limit(5).show()

orders_silver_df = orders_silver_df.filter(col("total_amount") > 0)
Products_silver_df = Products_silver_df.filter(col("Price") > 0)
orders_item_silver_df = orders_item_silver_df.filter((col("quantity") > 0) | (col("unit_price") > 0))

orders_silver_df.show()
Products_silver_df.show()
orders_item_silver_df.show()

invalid_order_items_df = orders_item_silver_df.join(orders_item_silver_df, on="order_id", how="left_anti")
invalid_order_items_df.show()

invalid_orders_df = orders_silver_df.join(customer_silver_df, on="customer_id", how="left_anti")
invalid_orders_df.show()

orders_silver_df=orders_silver_df.withColumnRenamed("ingest_timestamp",'os_ingest_timestamp')
orders_silver_df=orders_silver_df.withColumnRenamed("source_system",'os_source_system')

Products_silver_df=Products_silver_df.withColumnRenamed("ingest_timestamp",'ps_ingest_timestamp')
Products_silver_df=Products_silver_df.withColumnRenamed("source_system",'ps_source_system')

customer_silver_df.withColumnRenamed("ingest_timestamp",'cs_ingest_timestamp')
customer_silver_df.withColumnRenamed("source_system",'cs_source_system')

valid_order_items_df = orders_item_silver_df.join(orders_silver_df, on="order_id", how="inner")
valid_orders_df = orders_silver_df.join(customer_silver_df, on="customer_id", how="inner")
valid_product_df = Products_silver_df.join(orders_item_silver_df,on="product_id",how="inner")

valid_order_items_df.show()
valid_orders_df.show()
valid_product_df.show()
valid_order_items_df=valid_order_items_df.distinct()
valid_orders_df=valid_orders_df.distinct()
valid_product_df=valid_product_df.distinct()


valid_order_items_df.write.mode('overwrite').option("header","true").csv(r"C:\Users\konde\Desktop\Data\Scripts\Silver\order_items_order_id_in_order")

valid_orders_df .write.mode('overwrite').option("header","true").csv(r"C:\Users\konde\Desktop\Data\Scripts\Silver\orders_customer_id_in_customer")

valid_product_df.write.mode('overwrite').option("header","true").csv(r"C:\Users\konde\Desktop\Data\Scripts\Silver\order_items_product_id_in_product_id")

