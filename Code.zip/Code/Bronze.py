from pyspark.sql import SparkSession
from pyspark.sql.functions import *
from datetime import datetime




spark = SparkSession.builder.getOrCreate()

customer_df = spark.read.csv(r"C:\Users\konde\Desktop\Project\Data\Customers",header=True,inferSchema=True)
order_items_df = spark.read.csv(r"C:\Users\konde\Desktop\Project\Data\order_items",header=True,inferSchema=True)
orders_df = spark.read.csv(r"C:\Users\konde\Desktop\Project\Data\orders",header=True,inferSchema=True)
products_df = spark.read.csv(r"C:\Users\konde\Desktop\Project\Data\products",header=True,inferSchema=True)


customer_schema=["customer_id","full_name","email","address","city","state"]
order_items_schema=["order_item_id","order_id","product_id","quantity","unit_price"]
orders_schema=["order_id","order_date","customer_id","total_amount","order_status"]
products_schema=["product_id","product_name","category","price"]


customer_df_list=customer_df.columns
order_items_df_list=order_items_df.columns
orders_df_list=orders_df.columns
products_df_list=products_df.columns


def validate_schema(expected, actual):
    if expected == actual:
        print("✅ Schema matches!")
    else:
        print("❌ Schema mismatch!")
        print(f"Expected: {expected}")
        print(f"Actual:   {actual}")

validate_schema(customer_schema,customer_df_list)
validate_schema(order_items_schema,order_items_df_list)
validate_schema(orders_schema,orders_df_list)
validate_schema(products_schema,products_df_list)



customer_df = customer_df.withColumn("Ingest_timestamp", date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss")) \
                         .withColumn("Source_system", lit("Customer_CSV"))

order_items_df = order_items_df.withColumn("Ingest_timestamp", date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss")) \
                               .withColumn("Source_system", lit("Order_Item_CSV"))

orders_df = orders_df.withColumn("Ingest_timestamp", date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss")) \
                     .withColumn("Source_system", lit("Orders_CSV"))

products_df = products_df.withColumn("Ingest_timestamp", date_format(current_timestamp(), "yyyy-MM-dd HH:mm:ss")) \
                         .withColumn("Source_system", lit("Products_CSV"))


customer_df.limit(5).show()
order_items_df.limit(5).show()
orders_df.limit(5).show()
products_df.limit(5).show()

current_date = datetime.now().strftime("%Y-%m-%d")
customer_df.write.mode('overwrite').option("header", "true").csv(r"C:\Users\konde\Desktop\Data\Scripts\bronze\customers\{}".format(current_date))
order_items_df.write.mode('overwrite').option("header", "true").csv(r"C:\Users\konde\Desktop\Data\Scripts\bronze\Order_items\{}".format(current_date))
orders_df.write.mode('overwrite').option("header", "true").csv(r"C:\Users\konde\Desktop\Data\Scripts\bronze\orders\{}".format(current_date))
products_df.write.mode('overwrite').option("header", "true").csv(r"C:\Users\konde\Desktop\Data\Scripts\bronze\Products\{}".format(current_date))
